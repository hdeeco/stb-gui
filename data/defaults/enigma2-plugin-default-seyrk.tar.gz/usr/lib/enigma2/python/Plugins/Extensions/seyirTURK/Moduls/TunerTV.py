#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/TunerTV.py
import os
from datetime import datetime
from time import time
from Components.config import config
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eServiceCenter, eServiceReference, iServiceInformation

def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


class html_parser_TunerTV:

    def __init__(self):
        self.video_list = []
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = ''
        self.active_site_url = ''
        self.playlistname = ''
        self.playlist_cat_name = ''
        self.kino_title = ''
        self.category_back_url = ''
        self.error = ''

    def get_list(self, url):
        debug(url, 'MODUL URL: ')
        parts = url.split('@')
        url = parts[0]
        page = parts[1]
        list = []
        video_list_temp = []
        self.playlistname = 'TunerTV by tengildet'
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 195) || (type == 25) FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
        bouquets = services and services.getContent('SN', True)
        if page == 'start':
            chan_counter = 0
            for bouquet in bouquets:
                chan_counter = chan_counter + 1
                id = (chan_counter,
                 bouquet[1],
                 'http://seyirTURK.com 7/24 Eglencenizin Tek Adresi...',
                 None,
                 None,
                 'seyirTURKModul@TunerTV' + bouquet[0] + '@budur',
                 None,
                 '',
                 '',
                 None,
                 None)
                video_list_temp.append(id)

            self.video_list = video_list_temp
            return self.video_list
        if page == 'budur':
            services = serviceHandler.list(eServiceReference(url[7:]))
            channels = services and services.getContent('SN', True)
            for channel in channels:
                if not channel[0].startswith('1:64:'):
                    list.append(channel[1].replace('\xc2\x86', '').replace('\xc2\x87', ''))

            chan_counter = 0
            for channel in channels:
                try:
                    sid = channel[0][:channel[0].index('::') + 1]
                except:
                    sid = channel[0]

                chan_counter = chan_counter + 1
                id = (chan_counter,
                 channel[1],
                 'http://seyirTURK.com 7/24 Eglencenizin Tek Adresi...',
                 'http://dl.dropbox.com/u/99956746/image/picons/' + sid[:-1].replace(':', '_') + '.png',
                 'http://127.0.0.1:8001/' + channel[0],
                 None,
                 None,
                 'http://dl.dropbox.com/u/99956746/image/picons/' + sid[:-1].replace(':', '_') + '.png',
                 '',
                 None,
                 None)
                video_list_temp.append(id)

            self.next_page_url = 'seyirTURKModul@TunerTV@start@Tengildet'
            self.next_page_text = 'Favorilere Don'
            self.video_list = video_list_temp
            return self.video_list
