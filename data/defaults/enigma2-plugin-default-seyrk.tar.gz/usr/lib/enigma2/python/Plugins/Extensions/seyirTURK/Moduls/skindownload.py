#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/skindownload.py
from xml.etree import ElementTree
import urllib2
import urllib as ul
from time import sleep
import sys
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK')
import os, re, seyirTURKlanguage
from datetime import datetime
from time import time
from xml.dom import minidom
from Screens.MessageBox import MessageBox

def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


class html_parser_skindownload:

    def __init__(self):
        self.video_list = []
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = ''
        self.active_site_url = ''
        self.playlistname = ''
        self.playlist_cat_name = ''
        self.kino_title = ''
        self.category_back_url = ''
        self.error = ''

    def get_list(self, url):
        debug(url, 'MODUL URL: ')
        parts = url.split('@')
        video_list_temp = []
        url = parts[0]
        page = parts[1]
        name = parts[2].encode('utf-8')
        chan_counter = 0
        if len(parts) == 3:
            self.playlistname = 'seyirTURK Skins'
            if name == 'arayuz':
                urlid = 'http://seyirturk.com/enigma2download/skin.xml'
            if name == 'dil':
                urlid = 'http://seyirturk.com/enigma2download/language.xml'
            pageid = urllib2.urlopen(urlid)
            xmld = minidom.parse(pageid)
            data = xmld.getElementsByTagName('channel')
            chan_counter = 0
            for node in data:
                isim = node.getElementsByTagName('title')[0].firstChild.data.encode('utf-8').upper()
                poster = node.getElementsByTagName('logo_30x30')[0].firstChild.data.encode('utf-8')
                dwnld_url = node.getElementsByTagName('dwnld_url')[0].firstChild.data.encode('utf-8')
                chan_counter = chan_counter + 1
                idhistory1 = (chan_counter,
                 isim,
                 seyirTURKlanguage.skindownload1,
                 None,
                 None,
                 dwnld_url,
                 None,
                 poster,
                 '',
                 None,
                 None)
                video_list_temp.append(idhistory1)

        self.video_list = video_list_temp
        print video_list_temp
        if len(parts) == 4:
            surname = parts[3]
            if surname == 'sonerteng':
                dwnld = os.system('wget -c ' + parts[2] + ' -P /tmp')
                os.popen('rm -rf /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/img')
                os.remove('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/seyirTURKSkin.xml')
                os.system('opkg install /tmp/' + parts[2][-8:])
                os.remove('/tmp/' + parts[2][-8:])
                os.system('killall -9 enigma2')
            if surname == 'tengildet':
                dwnld = os.system('wget -c ' + parts[2] + ' -P /tmp')
                os.remove('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/seyirTURKlanguage.py')
                os.system('cp /tmp/seyirTURKlanguage.py /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/seyirTURKlanguage.py')
                os.remove('/tmp/seyirTURKlanguage.py')
                os.system('killall -9 enigma2')
            if name == 'guirestart':
                os.system('init 4')
                sleep(2)
                os.system('init 3')
            if name == 'reboot':
                os.system(name)
            if name == 'shutdown':
                os.system('shutdown -h now')
            if name == 'selfclose':
                self.close(None)
            if name == 'rtmp':
                self.uyari()
                tree = ElementTree.parse('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/seyirTURKConfig.xml')
                for author in tree.findall('password'):
                    author.text = '778gg8'
                    tree.write('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/seyirTURKConfig.xml')

    def meesage(self, session):
        self.session.open(MessageBox, _('Hello enigma2'), type=MessageBox.TYPE_INFO, timeout=10)

    def uyari(self):
        self.session.openWithCallback(self.tekrarbaslat, MessageBox, seyirTURKlanguage.plugin29, MessageBox.TYPE_YESNO)
