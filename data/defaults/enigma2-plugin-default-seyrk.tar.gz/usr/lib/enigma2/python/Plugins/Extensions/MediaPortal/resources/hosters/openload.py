﻿# -*- coding: utf-8 -*-
from Plugins.Extensions.MediaPortal.plugin import _
from Plugins.Extensions.MediaPortal.resources.imports import *

def openload(self, data):
	O = {
		'___': 0,
		'$$$$': "f",
		'__$': 1,
		'$_$_': "a",
		'_$_': 2,
		'$_$$': "b",
		'$$_$': "d",
		'_$$': 3,
		'$$$_': "e",
		'$__': 4,
		'$_$': 5,
		'$$__': "c",
		'$$_': 6,
		'$$$': 7,
		'$___': 8,
		'$__$': 9,
		'$_': "constructor",
		'$$': "return",
		'_$': "o",
		'_': "u",
		'__': "t",
	}

	result = re.search('<script[^>]*>\s*(O=.*?)</script>', data, re.DOTALL)
	if result:
		result = re.search('O\.\$\(O\.\$\((.*?)\)\(\)\)\(\);', result.group(1))
		if result:
			s1 = result.group(1)
			s1 = s1.replace(' ', '')
			s1 = s1.replace('(![]+"")', 'false')
			s3 = ''
			for s2 in s1.split('+'):
				if s2.startswith('O.'):
					s3 += str(O[s2[2:]])
				elif '[' in s2 and ']' in s2:
					key = s2[s2.find('[') + 3:-1]
					s3 += s2[O[key]]
				else:
					s3 += s2[1:-1]
			s3 = s3.replace('\\\\', '\\')
			s3 = s3.decode('unicode_escape')
			s3 = s3.replace('\\/', '/')
			s3 = s3.replace('\\\\"', '"')
			s3 = s3.replace('\\"', '"')
			url = re.search('<source\s+src="(.*?)"', s3)
			if url:
				self._callback(str(url.group(1)))
				return
	self.stream_not_found()