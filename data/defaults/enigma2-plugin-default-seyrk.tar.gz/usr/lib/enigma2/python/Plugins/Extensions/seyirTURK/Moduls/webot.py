#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/webot.py
from xml.etree.cElementTree import fromstring, ElementTree
import urllib2
import urllib as ul
import sys
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK')
import os, re, seyirTURKlanguage
from datetime import datetime
from time import time


def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


def mod_request(url, param = None):
    url = 'http://' + url
    html = ''
    try:
        debug(url, 'MODUL REQUEST URL')
        req = urllib2.Request(url, param, {'User-agent': 'Mozilla/5.0 seyirTURK_E2',
         'Connection': 'Close'})
        html = urllib2.urlopen(req).read()
    except Exception as ex:
        print ex
        print 'REQUEST Exception'

    return html

def getmac(eth):
    global MAC
    mac = None
    try:
        mac = os.popen("ip link show %s | awk '/ether/ {print $2}'" % eth).read()
        print 'os.popen'
    except Exception as ex:
        print ex
        print 'getmac'
        try:
            ifconfig = commands.getoutput('ifconfig ' + eth)
            print 'ifconfig'
            mac_search = re.search('\\w\\w:\\w\\w:.+\n', ifconfig)
            mac = mac_search.group(0).lower()
        except Exception as ex:
            print ex
            print 'getmac2'

    mac = mac.strip(' \t\n\r')
    if mac is None:
        parsedMac = 'macadresinibulamadim'
    else:
        parsedMac = mac
    MAC = parsedMac
    return parsedMac

class html_webot:

    def __init__(self):
        self.video_list = []
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = ''
        self.active_site_url = ''
        self.playlistname = ''
        self.playlist_cat_name = ''
        self.kino_title = ''
        self.category_back_url = ''
        self.error = ''

    def get_list(self, url):
        debug(url, 'MODUL URL: ')
        parts = url.split('@')
        video_list_temp = []
        url = parts[0]
        stream = None
        play = None
        page = parts[1]
        name = parts[2].encode('utf-8')
        self.search_text = seyirTURKlanguage.modul8
        self.search_on = 'search'
        chan_counter = 0
        if len(parts) == 3:
            self.playlistname = 'ARAMA'
            new = (1,
             seyirTURKlanguage.modul5,
             None,
             None,
             None,
             '',
             None,
             '',
             '',
             None,
             None)
            video_list_temp.append(new)
        if len(parts) == 4:
            try:
                mac_string = getmac('eth0')
                print 'MAC from Console'
            except:
                mac_string = 'macadresinibulamadim'
                print 'macadresinibulamadim'
            param = parts[3]
            url = parts[1] + param.replace(' ','%20') + '&mac=' + mac_string
            debug(url, 'Arama url: ')
            page = mod_request(url).encode('utf-8')
            results = re.findall('<title><!\\[CDATA\\[(.*?)\\]\\]><\\/title>\\s*<logo.*?30x30>\\s*<description><!.*?img src="(.*?)"height.*?top">(.*?)<\\/td>.*?description>\\s*<(.*?)_url.*?CDATA\\[(.*?)\\]\\]', page)
            self.playlistname = '"%s" - %i %s' % (parts[3], len(results), seyirTURKlanguage.modul6)
            for text in results:
                if text[3] == 'playlist':
                    play = text[4]
                    stream = None
                if text[3] == 'stream':
                    play = None
                    stream = text[4]
                img = text[1]
                title = text[0]
                title = re.sub('&[^;]*.', '', title)
                chan_counter += 1
                chan_tulpe = (chan_counter,
                 title,
                 text[2],
                 img,
                 stream,
                 play,
                 None,
                 img,
                 '',
                 None,
                 None)
                video_list_temp.append(chan_tulpe)

        self.prev_page_url = ''
        self.prev_page_text = 'BACK'
        self.video_list = video_list_temp
