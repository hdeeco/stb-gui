#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/seyirTURKModuls.py
from xml.etree.cElementTree import fromstring, ElementTree
import urllib2
try:
    import commands
except Exception as ex:
    print ex
import urllib as ul
import sys
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK')
import os, re, seyirTURKlanguage
import operator
from datetime import datetime
from time import time
from skindownload import html_parser_skindownload
from snailb import html_parser_snailb
from TunerTV import html_parser_TunerTV
from webot import html_webot

def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


def mod_request(url, param = None):
    url = 'http://' + url
    html = ''
    try:
        debug('allaalla', 'MODUL REQUEST URL')
        req = urllib2.Request(url, param, {'User-agent': 'Mozilla/5.0 seyirTURK_E2',
         'Connection': 'Close'})
        html = urllib2.urlopen(req).read()
    except Exception as ex:
        print ex
        print 'REQUEST Exception'

    return html


class html_parser_moduls:

    def __init__(self):
        self.video_list = []
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = ''
        self.active_site_url = ''
        self.playlistname = ''
        self.playlist_cat_name = ''
        self.kino_title = ''
        self.category_back_url = ''
        self.error = ''

    def reset_buttons(self):
        self.kino_title = ''
        self.next_page_url = None
        self.next_page_text = ''
        self.prev_page_url = None
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = None

    def get_list(self, url):
        debug('allaalla', 'MODUL URL: ')
        self.reset_buttons()
        if url.find('webot') > -1:
            webot = html_webot()
            webot.get_list(url)
            self.video_list = webot.video_list
            self.next_page_url = webot.next_page_url
            self.next_page_text = webot.next_page_text
            self.prev_page_url = webot.prev_page_url
            self.prev_page_text = webot.prev_page_text
            self.search_text = webot.search_text
            self.search_on = webot.search_on
            self.active_site_url = webot.active_site_url
            self.playlistname = webot.playlistname
            self.playlist_cat_name = webot.playlist_cat_name
            self.kino_title = webot.kino_title
            self.category_back_url = webot.category_back_url
            self.error = webot.error
        if url.find('TunerTV') > -1:
            TunerTV = html_parser_TunerTV()
            TunerTV.get_list(url)
            self.video_list = TunerTV.video_list
            self.next_page_url = TunerTV.next_page_url
            self.next_page_text = TunerTV.next_page_text
            self.prev_page_url = TunerTV.prev_page_url
            self.prev_page_text = TunerTV.prev_page_text
            self.search_text = TunerTV.search_text
            self.search_on = TunerTV.search_on
            self.active_site_url = TunerTV.active_site_url
            self.playlistname = TunerTV.playlistname
            self.playlist_cat_name = TunerTV.playlist_cat_name
            self.kino_title = TunerTV.kino_title
            self.category_back_url = TunerTV.category_back_url
            self.error = TunerTV.error
        if url.find('snailb') > -1:
            snailb = html_parser_snailb()
            snailb.get_list(url)
            self.video_list = snailb.video_list
            self.next_page_url = snailb.next_page_url
            self.next_page_text = snailb.next_page_text
            self.prev_page_url = snailb.prev_page_url
            self.prev_page_text = snailb.prev_page_text
            self.search_text = snailb.search_text
            self.search_on = snailb.search_on
            self.active_site_url = snailb.active_site_url
            self.playlistname = snailb.playlistname
            self.playlist_cat_name = snailb.playlist_cat_name
            self.kino_title = snailb.kino_title
            self.category_back_url = snailb.category_back_url
            self.error = snailb.error
        if url.find('skindownload') > -1:
            skindownload = html_parser_skindownload()
            skindownload.get_list(url)
            self.video_list = skindownload.video_list
            self.next_page_url = skindownload.next_page_url
            self.next_page_text = skindownload.next_page_text
            self.prev_page_url = skindownload.prev_page_url
            self.prev_page_text = skindownload.prev_page_text
            self.search_text = skindownload.search_text
            self.search_on = skindownload.search_on
            self.active_site_url = skindownload.active_site_url
            self.playlistname = skindownload.playlistname
            self.playlist_cat_name = skindownload.playlist_cat_name
            self.kino_title = skindownload.kino_title
            self.category_back_url = skindownload.category_back_url
            self.error = skindownload.error
        if url.find('m3u') > -1:
            parts = url.split('@')
            filename = parts[0]
            name = parts[2].encode('utf-8')
            self.playlistname = name
            ts = None
            if url.find('TS') > -1:
                ts = 'True'
            try:
                video_list_temp = []
                chan_counter = 0
                if filename.find('http') > -1:
                    url = filename.replace('http://', '')
                    myfile = mod_request(url)
                else:
                    myfile = open('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/%s' % filename, 'r').read()
                regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', myfile)
                if not len(regex) > 0:
                    regex = re.findall('((.*.+)(.*))', myfile)
                for text in regex:
                    title = text[0].strip()
                    url = text[1].strip()
                    chan_counter += 1
                    chan_tulpe = (chan_counter,
                     title,
                     '',
                     '',
                     url,
                     None,
                     None,
                     '',
                     '',
                     None,
                     ts)
                    video_list_temp.append(chan_tulpe)
                    if len(video_list_temp) < 1:
                        print 'ERROR m3u CAT LIST_LEN = %s' % len(video_list_temp)

            except:
                print 'ERROR m3u'

            return video_list_temp
        return self.video_list
