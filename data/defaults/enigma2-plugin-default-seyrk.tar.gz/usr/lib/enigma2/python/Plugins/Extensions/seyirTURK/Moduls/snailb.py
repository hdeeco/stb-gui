#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/Moduls/snailb.py
from xml.etree.cElementTree import fromstring, ElementTree
import urllib2, base64
import urllib as ul
import sys, json
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/seyirTURK')
import os, re
try:
    import commands
except Exception as ex:
    print ex
from datetime import datetime
from time import time
import seyirTURKKeyBoard
try:
    from Components.Network import iNetwork
except:
    print "iNetwork yok"
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigInteger, ConfigText, ConfigSelection, getConfigListEntry, ConfigSequence, ConfigDirectory, ConfigBoolean, ConfigClock
config.plugins.seyirTURK = ConfigSubsection()
ayar = config.plugins.seyirTURK.getSavedValue()
try:
    ayar['adult']
except:
    adult = 'Evet'
else:
    adult = 'Hayir'

def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


def mod_request(url, param = None):
    url = 'http://' + url
    html = ''
    try:
        debug(url, 'MODUL REQUEST URL')
        req = urllib2.Request(url, param, {'User-agent': 'Mozilla/5.0 seyirTURK_E2',
         'Connection': 'Close'})
        html = urllib2.urlopen(req)
    except Exception as ex:
        print ex
        print 'REQUEST Exception'

    return html


def getmac(eth):
    global MAC
    mac = None
    try:
        ifaces = iNetwork.getConfiguredAdapters()
        mac = iNetwork.getAdapterAttribute(ifaces[0], 'mac')
        print 'inework'
    except Exception as ex:
        print ex
        print 'getmac'
        try:
            ifconfig = commands.getoutput('ifconfig ' + eth)
            print 'ifconfig'
            mac_search = re.search('\\w\\w:\\w\\w:.+\n', ifconfig)
            mac = mac_search.group(0).lower()
        except Exception as ex:
            print ex
            print 'getmac2'

        mac = mac.strip(' \t\n\r')

    if mac is None:
        parsedMac = 'macadresinibulamadim'
    else:
        parsedMac = mac
    MAC = parsedMac
    return parsedMac


class html_parser_snailb:

    def __init__(self):
        self.video_list = []
        self.ana = []
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.search_text = ''
        self.search_on = ''
        self.active_site_url = ''
        self.playlistname = ''
        self.playlist_cat_name = ''
        self.kino_title = ''
        self.category_back_url = ''
        self.error = ''

    def get_list(self, url):
        debug(url, 'MODUL URL: ')
        ifconfig = getmac('eth0')
        print ifconfig
        parts = url.split('@')
        url = parts[0]
        page = parts[1]
        name = parts[2]
        if url == 'snailb':
            url = base64.b64decode(seyirTURKKeyBoard.root.rooturl).replace('http://','') + base64.b64decode("c25haWxiL3Nvbmpzb24ucGhwP21hYz0=") + ifconfig
        if page == 'start':
            self.playlistname = name
            self.video_list = self.get_snailb_categories(url)
        if page == 'ana':
            self.playlistname = name
            self.ana = self.get_snailb_ana(url)

    def get_snailb_categories(self, url):
        ifconfig = getmac('eth0')
        print ifconfig
        try:
            page = mod_request(url)
            jpage = json.load(page)
            next = str(jpage[0]['_var0'][0]['_var3']) + '&xml'
            prev = str(jpage[0]['_var0'][0]['_var1']) + '&xml'
            video_list_temp = []
            chan_counter = 0
            oncekiad = str(jpage[0]['_var0'][0]['_var2'])
            oncekiad = base64.b64decode(oncekiad[-4:] + oncekiad[:-4])
            sonrakiad = str(jpage[0]['_var0'][0]['_var4'])
            sonrakiad = base64.b64decode(sonrakiad[-4:] + sonrakiad[:-4])
            for portal in jpage[0]['_var5']:
                koruma = None
                title = base64.b64decode(str(portal['_var6'])[-4:] + str(portal['_var6'])[:-4])
                adr = str(portal['_varA'])
                if str(portal['_var9']) == 'snailb':
                    adr = 'adresyok'
                if portal['_var9']:
                    if not str(portal['_var9']).startswith('seyirTURKModul'):
                        adr = str(portal['_var9']) + '&xml'
                    else:
                        adr = str(portal['_var9'])
                resim = base64.b64decode(str(portal['_var8'])[-4:] + str(portal['_var8'])[:-4])
                if '159x159LogoRed' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvZmF2b3JpX2UyLnBuZw==")
                if 'series.png' in resim:
                    resim = base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvZGl6aWxlcl9lMi5wbmc=")
                if 'favori.png' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvZmF2b3JpX2UyLnBuZw==")
                if 'filmler.png' in resim:
                    resim = base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvZmlsbWxlcl9lMi5wbmc=")
                if 'portallar.png' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvZmF2b3JpX2UyLnBuZw==")
                if 'radyo.png' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvcmFkeW9fZTIucG5n")
                if 'search.png' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvc2VhcmNoX2UyLnBuZw==")
                if '18.png' in resim:
                    resim =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvMThfZTIucG5n")                    
                if 'tv.png' in resim:
                    resim = base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvdHZfZTIucG5n")
                if '.com/resimler/18.png' in resim:
                    resim = base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("cmVzaW1sZXIvdHZfZTIucG5n")  
                desc = base64.b64decode(str(portal['_varB'])[-4:] + str(portal['_varB'])[:-4]).replace('\n', ' ').replace('\r', ' ')
                if portal['_var9']:
                    if adr[:4] == 'seyi':
                        adres = adr
                        adres1 = None
                    if adr[:4] == 'http':
                        adres = 'seyirTURKModul@' + adr[7:] + '@start@' + title
                        adres1 = None
                    if adr[:25] == base64.b64decode(seyirTURKKeyBoard.root.rooturl).replace('com/','com'):
                        adres = adr[7:]
                        adres1 = None
                        desc = adr[7:]
                    if adr == 'Link Yok':
                        adres = None
                        adres1 = base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("bm9wbGF5bGlzdC5tcDQ=")
                if portal['_varA']:
                    adres1 = base64.b64decode(adr[-4:] + adr[:-4])
                    adres = None
                    if ':' not in base64.b64decode(adr[-4:] + adr[:-4]):
                        adres1 =  base64.b64decode(seyirTURKKeyBoard.root.rooturl) + base64.b64decode("bm92aWRlby5tcDQ=")
                        adres = None
                if portal['_varC'] == True:
                    koruma = 'True'
                if adult == 'Hayir':
                    if koruma != 'True':
                        chan_counter += 1
                        chan_tulpe = (chan_counter,
                         title,
                         desc,
                         resim,
                         adres1,
                         adres,
                         None,
                         resim,
                         '',
                         koruma,
                         None)
                        video_list_temp.append(chan_tulpe)
                if adult == 'Evet':
                    chan_counter += 1
                    chan_tulpe = (chan_counter,
                     title,
                     desc,
                     resim,
                     adres1,
                     adres,
                     None,
                     resim,
                     '',
                     koruma,
                     None)
                    video_list_temp.append(chan_tulpe)

            if len(next) > 4:
                if next[:4] == 'seyi':
                    self.next_page_url = next
                    self.next_page_text = sonrakiad
                else:
                    self.next_page_url = 'seyirTURKModul@' + next.replace('\\', '')[7:] + '@start@' + 'seyirTURK'
                    self.next_page_text = sonrakiad
            else:
                self.next_page_url = 'seyirTURKModul@' +base64.b64decode(seyirTURKKeyBoard.root.rooturl).replace('http://','') + base64.b64decode("c25haWxiL3Nvbmpzb24ucGhw") + '@start@seyirTURK'
                self.next_page_text = 'Ana Menu'
            if len(prev) > 4:
                if prev[:4] == 'seyi':
                    self.prev_page_url = prev
                    self.prev_page_text = oncekiad
                else:
                    self.prev_page_url = 'seyirTURKModul@' + prev.replace('\\', '')[7:] + '@start@seyirTURK'
                    self.prev_page_text = oncekiad
            else:
                self.prev_page_url = 'seyirTURKModul@' + base64.b64decode(seyirTURKKeyBoard.root.rooturl).replace('http://','') + base64.b64decode("c25haWxiL3Nvbmpzb24ucGhwP3VybD1wb3J0YWw=") + '@start@seyirTURK'
                self.prev_page_text = 'Portallar'
            if len(video_list_temp) < 1:
                print 'ERROR  = %s' % len(video_list_temp)
        except:
            print 'ERROR get_snailb_category'

        return video_list_temp
