VER=4.54
FONT_0 = ('seyirTURKRegularIPTV', 24)
FONT_1 = ('seyirTURKRegularIPTV', 24)
BLOCK_H = 37

